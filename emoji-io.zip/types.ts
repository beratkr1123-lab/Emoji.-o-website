import { LucideIcon } from 'lucide-react';

export interface FeatureProps {
  icon: LucideIcon;
  title: string;
  description: string;
  animationClass?: string;
}

export interface PricingPlanProps {
  price: string;
  subPrice: string;
  features: string[];
}

export interface ModeCardProps {
  title: string;
  icon: LucideIcon;
  features: string[];
  isOnline?: boolean;
}