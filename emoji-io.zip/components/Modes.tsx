import React from 'react';
import { User, Users, Globe, WifiOff, Wifi } from 'lucide-react';
import { ModeCardProps } from '../types';

const ModeCard: React.FC<ModeCardProps> = ({ title, icon: Icon, features, isOnline }) => (
  <div className="bg-gray-800 rounded-3xl p-8 border border-gray-700 hover:border-brand-purple/50 transition-all hover:shadow-2xl hover:shadow-brand-purple/10 group relative overflow-hidden">
    <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110`}>
        <Icon size={120} />
    </div>
    
    <div className="relative z-10">
        <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-bold mb-6 ${isOnline ? 'bg-green-500/20 text-green-400' : 'bg-gray-700 text-gray-300'}`}>
            {isOnline ? <Wifi size={14} /> : <WifiOff size={14} />}
            <span>{isOnline ? 'ONLINE' : 'OFFLINE'}</span>
        </div>
        
        <div className="w-16 h-16 bg-gray-700 rounded-2xl flex items-center justify-center mb-6 text-brand-yellow shadow-inner">
            <Icon size={32} />
        </div>
        
        <h3 className="text-2xl font-display font-bold text-white mb-4">{title}</h3>
        
        <ul className="space-y-3">
            {features.map((feature, idx) => (
                <li key={idx} className="flex items-start text-gray-400 text-sm">
                    <span className="mr-2 mt-1 w-1.5 h-1.5 bg-brand-purple rounded-full flex-shrink-0"></span>
                    {feature}
                </li>
            ))}
        </ul>
    </div>
  </div>
);

const Modes: React.FC = () => {
  const modes: ModeCardProps[] = [
    {
      title: "Tek Kişilik",
      icon: User,
      features: [
        "Rastgele emojilerle sonsuz oyun",
        "İpucu alma ve harf açma seçenekleri",
        "Rahat ve akıcı oynanış",
        "Kendi rekorunu kırmaya odaklan"
      ],
      isOnline: false
    },
    {
      title: "Karşılıklı (Tek Cihaz)",
      icon: Users,
      features: [
        "Aynı cihazdan 2 kişilik düello",
        "Sırayla tahmin yapma heyecanı",
        "En fazla bilen kazanır",
        "Arkadaşınla yan yana rekabet"
      ],
      isOnline: false
    },
    {
      title: "Online Mod",
      icon: Globe,
      features: [
        "Gerçek zamanlı oyuncular",
        "Bir kişi yazar, diğerleri tahmin eder",
        "Hızlı ve rekabetçi ortam"
      ],
      isOnline: true
    }
  ];

  return (
    <div id="modes" className="py-24 bg-gray-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brand-yellow font-bold tracking-wide uppercase text-sm mb-2">Oyun Mekanikleri</h2>
          <h3 className="text-3xl md:text-5xl font-display font-bold text-white">Nasıl Oynamak İstersin?</h3>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            İster internetin olmasın, ister arkadaşın yanında olsun, ister dünyanın öbür ucunda... Emoji IO her duruma uygun bir moda sahip.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {modes.map((mode, idx) => (
                <ModeCard key={idx} {...mode} />
            ))}
        </div>
      </div>
    </div>
  );
};

export default Modes;