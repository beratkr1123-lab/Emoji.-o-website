import React, { useState, useEffect } from 'react';
import { Gamepad2 } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navLinks = [
    { name: 'Oyun', id: 'game' },
    { name: 'Modlar', id: 'modes' },
    { name: 'Özellikler', id: 'features' },
    { name: 'Fiyat', id: 'pricing' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-gray-900/90 backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.5)] py-3 border-b border-gray-800/50' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0">
          
          {/* Logo Section */}
          <div className="flex items-center space-x-2 group cursor-pointer">
            <div className="bg-brand-yellow p-2 rounded-xl rotate-3 shadow-[0_0_15px_rgba(255,217,61,0.6)] group-hover:rotate-6 group-hover:shadow-[0_0_25px_rgba(255,217,61,0.8)] transition-all duration-300">
              <Gamepad2 className="h-6 w-6 text-brand-dark" />
            </div>
            <span className="font-display font-bold text-2xl tracking-wide text-white drop-shadow-[0_0_5px_rgba(255,255,255,0.3)] transition-all group-hover:drop-shadow-[0_0_10px_rgba(79,70,229,0.5)]">
              Emoji<span className="text-brand-yellow drop-shadow-[0_0_8px_rgba(255,217,61,0.6)]">IO</span>
            </span>
          </div>

          {/* Navigation Links - Always Visible */}
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.id)}
                className="text-gray-300 hover:text-brand-yellow transition-colors font-medium text-sm uppercase tracking-wider bg-transparent border-none cursor-pointer hover:drop-shadow-[0_0_5px_rgba(255,217,61,0.5)]"
              >
                {link.name}
              </button>
            ))}
            <button className="bg-brand-purple hover:bg-indigo-600 text-white px-4 py-1.5 md:px-6 md:py-2 rounded-full font-bold transition-all transform hover:scale-105 shadow-[0_0_15px_rgba(79,70,229,0.5)] hover:shadow-[0_0_25px_rgba(79,70,229,0.8)] text-sm border border-indigo-400/30">
              Çok Yakında
            </button>
          </div>

        </div>
      </div>
    </nav>
  );
};

export default Navbar;