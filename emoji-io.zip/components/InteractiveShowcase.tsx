import React, { useRef, useState } from 'react';

const InteractiveShowcase: React.FC = () => {
  const textRef = useRef<HTMLHeadingElement>(null); // Referansı text elementine taşıdık
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!textRef.current) return;

    const rect = textRef.current.getBoundingClientRect();
    
    // Koordinatları doğrudan yazı elementine göre hesaplıyoruz
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setPosition({ x, y });
    setOpacity(1);
  };

  const handleMouseLeave = () => {
    setOpacity(0);
  };

  return (
    <div 
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative w-full py-32 md:py-48 bg-black overflow-hidden flex flex-col items-center justify-center cursor-default group"
    >
      {/* Background Mesh Gradients (Subtle ambient light) */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,_rgba(79,70,229,0.1),transparent_70%)]"></div>

      <div className="relative z-10 text-center px-4">
        <p className="text-gray-500 font-medium tracking-[0.2em] mb-4 text-sm md:text-base uppercase animate-fade-in-up">
          Yeni Nesil Deneyim
        </p>

        {/* 
            APPLE STYLE TEXT EFFECT IMPROVED:
            Coordinates are now calculated relative to the H2 element itself.
        */}
        <h2 
          ref={textRef}
          className="text-7xl md:text-9xl lg:text-[10rem] font-display font-black tracking-tighter leading-none select-none transition-colors duration-200"
          style={{
            color: 'rgba(255, 255, 255, 0.1)', // Default dim color
            backgroundImage: `radial-gradient(
              circle 250px at ${position.x}px ${position.y}px, 
              #FFD93D 0%, 
              #FF6B6B 30%, 
              #4F46E5 60%, 
              transparent 100%
            )`,
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
            WebkitTextFillColor: opacity === 1 ? 'transparent' : 'rgba(255, 255, 255, 0.1)',
            // Geçişlerin daha yumuşak olması için ufak bir transition eklemiyoruz çünkü background-position transition'ı lag yapar.
            // React state update anlık (instant) olmalı.
          }}
        >
          EMOJI IO
        </h2>

        <p className="mt-8 text-gray-400 max-w-lg mx-auto text-lg leading-relaxed opacity-60 group-hover:opacity-100 transition-opacity duration-500">
          Işığı takip et. Sınırları zorla.
        </p>
      </div>

      {/* Grid Overlay for Tech Feel */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>
    </div>
  );
};

export default InteractiveShowcase;