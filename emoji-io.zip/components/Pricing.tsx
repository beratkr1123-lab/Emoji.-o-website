import React from 'react';
import { Check } from 'lucide-react';

const Pricing: React.FC = () => {
  return (
    <div id="pricing" className="py-24 relative overflow-hidden">
      {/* Decorative gradient background for pricing */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-dark to-indigo-950/20 -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">
                Standart Fiyat
            </h2>
            <p className="text-xl text-gray-300 mb-12">
                Sadece bir kahve fiyatına. İçerik üreticileri ve internetsiz eğlence arayanlar için.
            </p>
            
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl p-[2px] w-full max-w-md mx-auto transform hover:scale-105 transition-all duration-300 shadow-2xl shadow-indigo-500/20">
                <div className="bg-gray-900 rounded-[22px] p-8 h-full flex flex-col items-center">
                    
                    {/* Price Section */}
                    <div className="flex flex-col items-center justify-center mb-8 mt-2 w-full">
                        <h3 className="text-5xl md:text-6xl font-display font-extrabold text-white mb-2 tracking-tight">
                            39.90 ₺
                        </h3>
                        <span className="text-gray-400 text-sm uppercase tracking-wider font-medium">Tek Seferlik Ödeme</span>
                    </div>
                    
                    <div className="w-full border-t border-gray-800 my-4"></div>
                    
                    <ul className="space-y-4 w-full text-left mb-8 px-4 mt-2">
                        {[
                            "Tüm modlar sınırsız erişim",
                            "Günlük küre",
                            "Sade, göz yormayan tasarım",
                            "Reklamsız deneyim",
                            "Ömür boyu kullanım hakkı"
                        ].map((item, i) => (
                            <li key={i} className="flex items-center text-gray-300">
                                <div className="bg-brand-yellow/20 p-1 rounded-full mr-3 text-brand-yellow shrink-0">
                                    <Check size={16} strokeWidth={3} />
                                </div>
                                <span className="font-bold">{item}</span>
                            </li>
                        ))}
                    </ul>
                    
                    <button className="w-full bg-brand-purple hover:bg-indigo-600 text-white font-bold py-4 rounded-xl transition-colors shadow-lg shadow-indigo-500/40 flex items-center justify-center gap-2 group cursor-default">
                        <span>Çok Yakında</span>
                    </button>
                    <p className="mt-4 text-xs text-gray-500">Google Play & App Store</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;