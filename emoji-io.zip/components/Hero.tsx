import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles, Lightbulb, Key, Trophy, CheckCircle2, WifiOff } from 'lucide-react';

const Hero: React.FC = () => {
  const [demoInput, setDemoInput] = useState('');
  const [demoScore, setDemoScore] = useState(1240);
  const [showToast, setShowToast] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  
  // Yeni State'ler
  const [hintCount, setHintCount] = useState(3);
  const [letterCount, setLetterCount] = useState(3);
  const [activeHint, setActiveHint] = useState<string | null>(null);

  const TARGET_WORD = "GÜLMEK";

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDemoSubmit = () => {
    if (isCompleted) return;

    if (demoInput.toLocaleUpperCase('tr-TR') === TARGET_WORD) {
        setDemoScore(prev => prev + 1);
        setIsCompleted(true);
        setShowToast(true);
        setActiveHint(null); // Varsa ipucunu kapat
        
        setTimeout(() => {
            setShowToast(false);
        }, 3000);
    } else {
        const inputContainer = document.getElementById('game-input-container');
        if (inputContainer) {
            inputContainer.classList.add('border-red-500', 'shake-animation');
            setTimeout(() => {
                inputContainer.classList.remove('border-red-500', 'shake-animation');
            }, 500);
        }
    }
  };

  // İpucu Kullanma Fonksiyonu
  const handleUseHint = () => {
    if (isCompleted || hintCount <= 0) return;

    setHintCount(prev => prev - 1);
    setActiveHint("Kahkaha atma eylemi.");

    // 4 saniye sonra ipucunu gizle
    setTimeout(() => {
        setActiveHint(null);
    }, 4000);
  };

  // Harf Açma Fonksiyonu
  const handleRevealLetter = () => {
    if (isCompleted || letterCount <= 0) return;

    // Hedef kelime ile şu anki girdiyi karşılaştır
    const currentInput = demoInput.toLocaleUpperCase('tr-TR').split('');
    const targetInput = TARGET_WORD.split('');
    
    // İlk yanlış veya boş harfin indexini bul
    let indexToReveal = -1;
    for (let i = 0; i < targetInput.length; i++) {
        // Eğer harf boşsa veya yanlışsa bu indexi açalım
        if (!currentInput[i] || currentInput[i] !== targetInput[i]) {
            indexToReveal = i;
            break;
        }
    }

    if (indexToReveal !== -1) {
        // Girdiyi güncelle
        const newInput = [...currentInput];
        // Dizi boyutu yetersizse boşluklarla doldur
        while (newInput.length < targetInput.length) newInput.push('');
        
        newInput[indexToReveal] = targetInput[indexToReveal];
        
        setDemoInput(newInput.join('').slice(0, 6)); // Max 6 karakter
        setLetterCount(prev => prev - 1);

        // Eğer harf açınca kelime tamamlandıysa otomatik kontrol etme (Kullanıcı GÖNDER'e basmalı hissi için)
    }
  };

  return (
    <div id="game" className="relative pt-36 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Custom Styles for animation */}
      <style>{`
        .shake-animation {
            animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
        }
        @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
        }
      `}</style>

      {/* Background Elements - Animated Blobs */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-brand-dark to-gray-900 -z-20"></div>
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-purple/20 rounded-full blur-[120px] -z-10 animate-blob mix-blend-screen"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-brand-yellow/10 rounded-full blur-[120px] -z-10 animate-blob animation-delay-2000 mix-blend-screen"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-[120px] -z-10 animate-blob animation-delay-4000 mix-blend-screen"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center space-x-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-full px-4 py-2 mb-8 animate-fade-in-up shadow-[0_0_15px_rgba(79,70,229,0.3)]">
            <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-sm text-gray-300 font-medium tracking-wide">Yeni Nesil Kelime Oyunu</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-extrabold text-white tracking-tight mb-8 leading-tight drop-shadow-[0_0_25px_rgba(255,255,255,0.2)]">
            Emojileri Bil,<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-yellow via-orange-400 to-brand-accent drop-shadow-sm">
              Eğlenceyi Yakala!
            </span>
          </h1>
          
          <p className="mt-6 text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
            Emoji IO, emojileri tahmin etmeye dayalı, sade ve eğlenceli bir oyundur. 
            İster çevrimiçi ister <span className="text-brand-yellow font-bold drop-shadow-[0_0_8px_rgba(255,217,61,0.5)]">internetsiz</span> oynayın. Her turda rastgele gelen emojilerle zihnini zorla ve arkadaşlarına meydan oku.
          </p>
          
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              className="w-full sm:w-auto px-8 py-4 bg-white text-brand-dark rounded-xl font-bold text-lg hover:bg-gray-100 transition-all transform hover:-translate-y-1 shadow-[0_0_20px_rgba(255,255,255,0.3)] flex items-center justify-center space-x-2 cursor-default group"
            >
              <span className="group-hover:scale-105 transition-transform">Çok Yakında</span>
            </button>
            <button 
              onClick={() => scrollToSection('features')}
              className="w-full sm:w-auto px-8 py-4 bg-gray-800 text-white border border-gray-700 rounded-xl font-bold text-lg hover:bg-gray-700 hover:border-gray-500 transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-lg"
            >
              <span>Detayları İncele</span>
            </button>
          </div>

          {/* Nasıl Oynanır Section */}
          <div className="mt-16 bg-gray-900/40 backdrop-blur-md border border-gray-800 rounded-2xl p-6 max-w-3xl mx-auto animate-fade-in-up hover:border-brand-purple/30 transition-colors duration-500">
              <h3 className="text-brand-yellow font-display font-bold text-lg mb-6 flex items-center justify-center tracking-widest uppercase">
                  NASIL OYNANIR?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-left">
                  <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50 flex flex-col items-center text-center space-y-3 hover:bg-gray-800 transition-colors group hover:shadow-[0_0_15px_rgba(79,70,229,0.15)]">
                      <div className="w-10 h-10 bg-brand-purple/20 text-brand-purple rounded-full flex items-center justify-center font-display font-bold text-xl border border-brand-purple/30 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(79,70,229,0.2)]">1</div>
                      <span className="text-sm font-medium text-gray-300">Emoji gelir</span>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50 flex flex-col items-center text-center space-y-3 hover:bg-gray-800 transition-colors group hover:shadow-[0_0_15px_rgba(79,70,229,0.15)]">
                      <div className="w-10 h-10 bg-brand-purple/20 text-brand-purple rounded-full flex items-center justify-center font-display font-bold text-xl border border-brand-purple/30 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(79,70,229,0.2)]">2</div>
                      <span className="text-sm font-medium text-gray-300">Tahmin yazılır</span>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50 flex flex-col items-center text-center space-y-3 hover:bg-gray-800 transition-colors group hover:shadow-[0_0_15px_rgba(79,70,229,0.15)]">
                      <div className="w-10 h-10 bg-brand-purple/20 text-brand-purple rounded-full flex items-center justify-center font-display font-bold text-xl border border-brand-purple/30 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(79,70,229,0.2)]">3</div>
                      <span className="text-sm font-medium text-gray-300">İpucu alınır</span>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50 flex flex-col items-center text-center space-y-3 hover:bg-gray-800 transition-colors group hover:shadow-[0_0_15px_rgba(79,70,229,0.15)]">
                      <div className="w-10 h-10 bg-brand-purple/20 text-brand-purple rounded-full flex items-center justify-center font-display font-bold text-xl border border-brand-purple/30 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(79,70,229,0.2)]">4</div>
                      <span className="text-sm font-medium text-gray-300">Doğruysa devam!</span>
                  </div>
              </div>
          </div>
        </div>

        {/* Floating Emojis Visual & Playable Demo */}
        <div className="mt-20 relative w-full max-w-5xl mx-auto flex justify-center items-center py-10 min-h-[600px]">
             
            {/* Background Floating Emojis - Positioned Absolute to the Flex Container */}
            <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
                <div className="emoji-float absolute top-10 left-4 md:left-20 text-6xl md:text-8xl opacity-80 drop-shadow-[0_0_15px_rgba(255,217,61,0.3)]" style={{animationDelay: '0s'}}>🤔</div>
                <div className="emoji-float absolute bottom-20 right-4 md:right-20 text-6xl md:text-8xl opacity-80 drop-shadow-[0_0_15px_rgba(255,107,107,0.3)]" style={{animationDelay: '2s'}}>🎉</div>
                <div className="emoji-float absolute top-20 right-10 md:right-1/4 text-5xl md:text-7xl opacity-60 blur-[1px]" style={{animationDelay: '1s'}}>🚀</div>
                <div className="emoji-float absolute bottom-10 left-10 md:left-1/4 text-5xl md:text-7xl opacity-60 blur-[1px]" style={{animationDelay: '3s'}}>💡</div>
            </div>
            
            {/* Playable Phone Card Container for Animation Isolation */}
            <div className="relative z-10 w-full max-w-sm animate-float-slow">
                <div className="bg-gray-900/90 backdrop-blur-xl border border-gray-600/50 rounded-3xl p-6 shadow-[0_0_40px_rgba(79,70,229,0.25)] w-full transform rotate-3 hover:rotate-0 transition-all duration-500 flex flex-col hover:shadow-[0_0_60px_rgba(79,70,229,0.5)] hover:scale-[1.02]">
                    
                    {/* Top Info Bar: NO LEVEL anymore */}
                    <div className="flex justify-between items-center mb-6 px-1">
                        <div className="flex space-x-2">
                            <div className="bg-gray-800/80 px-3 py-1.5 rounded-lg border border-gray-700/50 flex items-center justify-center text-gray-400 shadow-inner" title="Offline Mod">
                                <WifiOff size={16} />
                            </div>
                        </div>

                            <div className="bg-gray-800/80 px-3 py-1.5 rounded-lg border border-gray-700/50 flex items-center space-x-2 shadow-inner">
                            <Trophy size={14} className="text-brand-purple drop-shadow-[0_0_5px_rgba(79,70,229,0.8)]" />
                            <span className="text-white font-display font-bold text-lg">{demoScore}</span>
                        </div>
                    </div>

                    {/* Game Content - Always Visible */}
                    <div className="flex-1 flex flex-col relative">
                        {/* Top Buttons: İpucu & Harf Aç */}
                        <div className="flex justify-between items-center mb-6">
                            <button 
                                onClick={handleUseHint}
                                disabled={hintCount === 0 || isCompleted}
                                className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${hintCount === 0 || isCompleted ? 'bg-gray-700 text-gray-500 cursor-not-allowed' : 'bg-gray-800 hover:bg-gray-700 text-brand-yellow shadow-[0_0_10px_rgba(255,217,61,0.2)]'}`}
                            >
                                <Lightbulb size={14} />
                                <span>İPUCU ({hintCount})</span>
                            </button>
                            <button 
                                onClick={handleRevealLetter}
                                disabled={letterCount === 0 || isCompleted}
                                className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${letterCount === 0 || isCompleted ? 'bg-gray-700 text-gray-500 cursor-not-allowed' : 'bg-gray-800 hover:bg-gray-700 text-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.2)]'}`}
                            >
                                <Key size={14} />
                                <span>HARF AÇ ({letterCount})</span>
                            </button>
                        </div>

                        {/* Main Emoji and Hint Bubble */}
                        <div className="flex justify-center mb-6 relative">
                            <span className="text-8xl drop-shadow-[0_0_20px_rgba(255,255,255,0.2)] animate-bounce" style={{ animationDuration: '3s' }}>😂</span>
                            
                            {/* İpucu Balonu */}
                            {activeHint && (
                                <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 bg-white text-brand-dark p-3 rounded-xl shadow-[0_0_20px_rgba(255,255,255,0.4)] z-20 animate-fade-in-up">
                                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-white transform rotate-45"></div>
                                    <p className="text-xs font-bold text-center leading-tight">{activeHint}</p>
                                </div>
                            )}
                        </div>

                        {/* Word Placeholders (Filled by input) */}
                        <div className="flex justify-center space-x-1 mb-6">
                            {[...Array(6)].map((_, i) => (
                                    <div key={i} className={`w-9 h-11 border-b-4 ${isCompleted ? 'border-green-500 bg-green-500/20 text-green-400 shadow-[0_0_10px_rgba(34,197,94,0.3)]' : 'border-gray-500 bg-gray-800/50 text-white'} rounded-sm flex items-center justify-center text-xl font-bold uppercase transition-colors duration-300`}>
                                        {isCompleted ? TARGET_WORD[i] : (demoInput[i] || '')}
                                    </div>
                            ))}
                        </div>

                        {/* Input Area */}
                        <div id="game-input-container" className="relative mb-4 border-2 border-transparent rounded-xl transition-all">
                            <input 
                                type="text" 
                                maxLength={6}
                                value={demoInput}
                                onChange={(e) => !isCompleted && setDemoInput(e.target.value)}
                                placeholder={isCompleted ? "TEBRİKLER!" : "Buraya Yaz..."}
                                disabled={isCompleted}
                                className="w-full bg-gray-900/80 border-2 border-dashed border-gray-700 rounded-xl p-3 text-center text-white font-bold tracking-widest uppercase focus:outline-none focus:border-brand-purple focus:shadow-[0_0_15px_rgba(79,70,229,0.3)] transition-all placeholder:text-gray-600 placeholder:normal-case placeholder:font-normal disabled:opacity-50 disabled:cursor-not-allowed"
                            />
                        </div>

                        {/* Send Button */}
                        <button 
                            onClick={handleDemoSubmit}
                            disabled={isCompleted}
                            className={`w-full py-3 rounded-xl font-display font-bold text-lg shadow-lg transition-all transform active:scale-95 ${isCompleted ? 'bg-gray-600 text-gray-300 cursor-not-allowed' : 'bg-green-500 hover:bg-green-600 text-white shadow-[0_0_20px_rgba(34,197,94,0.4)]'}`}
                        >
                            {isCompleted ? 'TAMAMLANDI' : 'GÖNDER'}
                        </button>
                        <div className="text-center mt-2">
                            <span className="text-[10px] text-gray-500 uppercase tracking-widest opacity-60">Deneme Turu</span>
                        </div>
                    
                        {/* Toast Notification (Alttan çıkan kart) */}
                        <div className={`absolute bottom-16 left-0 right-0 flex justify-center pointer-events-none transition-all duration-500 transform ${showToast ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                            <div className="bg-white text-brand-dark px-6 py-3 rounded-full shadow-[0_0_25px_rgba(34,197,94,0.5)] flex items-center space-x-2 border-2 border-green-500">
                                <CheckCircle2 className="text-green-600 w-6 h-6" />
                                <span className="font-display font-bold text-lg">DOĞRU!</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;