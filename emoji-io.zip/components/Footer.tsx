import React, { useState } from 'react';
import { Gamepad2, X, Shield, ScrollText, AlertCircle, CheckCircle2, Youtube, ThumbsUp, ThumbsDown, SendHorizontal } from 'lucide-react';

const Footer: React.FC = () => {
  const [activeModal, setActiveModal] = useState<'privacy' | 'terms' | null>(null);

  const openModal = (type: 'privacy' | 'terms') => {
    setActiveModal(type);
    document.body.style.overflow = 'hidden'; // Sayfa kaydırmayı engelle
  };

  const closeModal = () => {
    setActiveModal(null);
    document.body.style.overflow = 'unset'; // Sayfa kaydırmayı geri aç
  };

  return (
    <>
      <footer className="bg-gray-950 border-t border-gray-900 pt-16 pb-8 relative z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-12 gap-10 lg:gap-0">
              <div className="flex items-center space-x-2 self-start lg:self-center">
                  <div className="bg-brand-yellow p-1.5 rounded-lg">
                    <Gamepad2 className="h-5 w-5 text-brand-dark" />
                  </div>
                  <span className="font-display font-bold text-xl text-white">
                    Emoji<span className="text-brand-yellow">IO</span>
                  </span>
              </div>
              
              {/* İletişim ve Sosyal Medya Alanı */}
              <div className="flex flex-col md:flex-row items-start md:items-start gap-8 w-full md:w-auto">
                  
                  {/* YouTube Badge */}
                  <div className="flex items-center space-x-3 bg-red-600/10 px-5 py-3 rounded-2xl border border-red-600/20 cursor-default h-fit whitespace-nowrap">
                      <div className="bg-red-600 p-2 rounded-full text-white shadow-lg shadow-red-600/20">
                        <Youtube size={18} fill="currentColor" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-red-400 text-xs font-bold uppercase tracking-wider">Abone Ol</span>
                        <span className="text-white font-medium text-sm">Emoji IO</span>
                      </div>
                  </div>

                  {/* YouTube Comment Section Simulation */}
                  <div className="flex flex-col gap-4 w-full max-w-md bg-gray-900/50 p-4 rounded-xl border border-gray-800">
                      
                      {/* Pinned Developer Comment */}
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-purple to-indigo-600 flex items-center justify-center shrink-0 border border-white/10 shadow-inner mt-0.5">
                            <span className="font-bold text-white text-xs">IO</span>
                        </div>
                        
                        <div className="flex flex-col">
                            <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-[11px] font-bold text-white bg-gray-800 px-2 py-0.5 rounded-full border border-gray-700">@EmojiIO_Destek</span>
                                <span className="text-[10px] text-gray-500">Sabitlendi</span>
                            </div>
                            
                            <p className="text-xs md:text-sm text-gray-300 leading-snug">
                                Sorularınız, hata bildirimleri veya önerileriniz mi var? Yorumlarda bize yazın, ekibimiz anında yanıtlasın! 👇
                            </p>
                            
                            <div className="flex items-center gap-4 mt-2">
                                <div className="flex items-center gap-1.5 group/like cursor-pointer">
                                    <ThumbsUp size={12} className="text-gray-500 group-hover/like:text-white transition-colors" />
                                    <span className="text-[10px] text-gray-500 group-hover/like:text-white">1.2B</span>
                                </div>
                                <div className="flex items-center group/dislike cursor-pointer">
                                    <ThumbsDown size={12} className="text-gray-500 group-hover/dislike:text-white transition-colors" />
                                </div>
                                <span className="text-[10px] font-bold text-gray-500 hover:text-white cursor-pointer ml-1">YANITLA</span>
                            </div>
                        </div>
                      </div>

                      {/* Fake User Input Line */}
                      <div className="flex items-center gap-3 pl-1 pt-1 opacity-70 hover:opacity-100 transition-opacity cursor-text">
                           <div className="w-7 h-7 rounded-full bg-gray-700 flex items-center justify-center shrink-0">
                                <span className="text-[10px] text-gray-400">Siz</span>
                           </div>
                           <div className="flex-1 border-b border-gray-700 pb-2 flex justify-between items-center group">
                                <span className="text-xs text-gray-500 group-hover:text-gray-400">Yorum ekleyin...</span>
                                <SendHorizontal size={14} className="text-gray-600 group-hover:text-brand-yellow transition-colors" />
                           </div>
                      </div>

                  </div>
              </div>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center border-t border-gray-900 pt-8 text-sm text-gray-500">
              <p>&copy; {new Date().getFullYear()} Emoji IO. Tüm hakları saklıdır.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                  <button onClick={() => openModal('privacy')} className="hover:text-gray-300 transition-colors">Gizlilik Politikası</button>
                  <button onClick={() => openModal('terms')} className="hover:text-gray-300 transition-colors">Kullanım Şartları</button>
              </div>
          </div>
        </div>
      </footer>

      {/* Modal Overlay */}
      {activeModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity" 
            onClick={closeModal}
          ></div>
          
          <div className="bg-gray-900 border border-gray-700 rounded-3xl w-full max-w-2xl relative z-10 shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-fade-in-up">
            <div className="p-6 border-b border-gray-800 flex justify-between items-center bg-gray-900 sticky top-0">
              <h3 className="text-xl md:text-2xl font-display font-bold text-white flex items-center gap-2">
                {activeModal === 'privacy' ? <Shield className="text-brand-purple" /> : <ScrollText className="text-brand-purple" />}
                {activeModal === 'privacy' ? 'Gizlilik Politikası' : 'Kullanım Şartları'}
              </h3>
              <button 
                onClick={closeModal}
                className="p-2 bg-gray-800 hover:bg-gray-700 rounded-full text-gray-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto custom-scrollbar">
              <div className="bg-gray-800/30 rounded-2xl p-1 border border-gray-700/30">
                 
                 {/* İçerik Alanı */}
                <div className="bg-brand-dark/80 rounded-xl p-6 md:p-8 border border-gray-800 text-left relative overflow-hidden">
                    
                    {/* Arka plan efekti */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-brand-purple/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

                    {activeModal === 'privacy' ? (
                        <div className="space-y-6 text-gray-300">
                            <p className="font-medium text-white text-lg">
                                🔐 Emoji IO olarak kullanıcı gizliliğine önem veriyoruz.
                            </p>
                            <p>
                                Bu web sitesi ve oyun, kullanıcı deneyimini sunmak amacıyla çalışır ve kişisel bilgileri zorunlu olarak toplamaz.
                            </p>
                            
                            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700/50">
                                <ul className="space-y-3">
                                    <li className="flex items-start gap-2">
                                        <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                                        <span>Offline modlarda oynanan oyunlarda herhangi bir veri kaydı veya paylaşımı yapılmaz.</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <AlertCircle className="w-5 h-5 text-brand-yellow mt-0.5 shrink-0" />
                                        <span>Online modda ise oyunun düzgün çalışabilmesi için yalnızca teknik ve anonim veriler (bağlantı durumu, oyun içi hareketler gibi) işlenebilir.</span>
                                    </li>
                                </ul>
                            </div>

                            <div>
                                <h4 className="text-brand-yellow font-bold mb-2">Toplanan veriler:</h4>
                                <ul className="list-disc list-inside space-y-1 ml-2 text-gray-400">
                                    <li>Kimlik tespiti amacıyla kullanılmaz</li>
                                    <li>Üçüncü taraflarla paylaşılmaz</li>
                                    <li>Reklam veya pazarlama amacıyla kullanılmaz</li>
                                </ul>
                            </div>

                            <p>
                                Kullanıcılar diledikleri zaman oyunu kullanmayı bırakabilir.
                            </p>
                            <p className="text-sm text-gray-500 italic border-t border-gray-800 pt-4">
                                Emoji IO, gizlilik politikasını gerektiğinde güncelleme hakkını saklı tutar.
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-6 text-gray-300">
                             <p className="font-medium text-white text-lg">
                                📜 Emoji IO’yu kullanarak aşağıdaki şartları kabul etmiş olursunuz.
                            </p>
                            
                            <ul className="space-y-4">
                                <li className="flex items-start gap-3 bg-gray-900/40 p-3 rounded-lg">
                                    <div className="w-2 h-2 mt-2 rounded-full bg-brand-purple shrink-0"></div>
                                    <span>Oyun tamamen eğlence amaçlıdır.</span>
                                </li>
                                <li className="flex items-start gap-3 bg-gray-900/40 p-3 rounded-lg">
                                    <div className="w-2 h-2 mt-2 rounded-full bg-brand-purple shrink-0"></div>
                                    <span>Oyunun kötüye kullanılması, hile yapılması veya diğer oyuncuların deneyimini bozacak davranışlar yasaktır.</span>
                                </li>
                                <li className="flex items-start gap-3 bg-gray-900/40 p-3 rounded-lg">
                                    <div className="w-2 h-2 mt-2 rounded-full bg-brand-purple shrink-0"></div>
                                    <span>Online modda uygunsuz içerik paylaşımı yasaktır.</span>
                                </li>
                                <li className="flex items-start gap-3 bg-gray-900/40 p-3 rounded-lg">
                                    <div className="w-2 h-2 mt-2 rounded-full bg-brand-purple shrink-0"></div>
                                    <span>Oyunun içeriği ve sistemi izinsiz kopyalanamaz veya dağıtılamaz.</span>
                                </li>
                            </ul>

                            <p>
                                Emoji IO, oyunun içeriğinde ve özelliklerinde önceden haber vermeksizin değişiklik yapma hakkını saklı tutar.
                            </p>
                            <p>
                                Kullanıcı, oyunu kullanırken doğabilecek teknik aksaklıkları kabul eder.
                            </p>
                        </div>
                    )}
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-gray-800 bg-gray-900 flex justify-end">
              <button 
                onClick={closeModal}
                className="px-8 py-3 bg-white text-brand-dark rounded-xl font-bold hover:bg-gray-100 transition-colors shadow-lg"
              >
                Anladım
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Footer;