import React from 'react';
import { Gift, RotateCcw, Languages, Sparkles, Zap, Layout } from 'lucide-react';
import { FeatureProps } from '../types';

const FeatureItem: React.FC<FeatureProps> = ({ icon: Icon, title, description, animationClass }) => (
  <div className="flex flex-col items-center text-center p-6 bg-gray-800/50 rounded-2xl border border-gray-700 hover:bg-gray-800 transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-brand-purple/10 group cursor-default">
    <div className="w-12 h-12 bg-brand-purple/20 text-brand-purple rounded-xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-brand-purple/30 group-hover:scale-110">
      <Icon size={24} className={`transition-all duration-500 ${animationClass}`} />
    </div>
    <h4 className="text-lg font-bold text-white mb-2">{title}</h4>
    <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
  </div>
);

const Features: React.FC = () => {
  const features: FeatureProps[] = [
    {
      icon: Gift,
      title: "Günlük Ödüller",
      description: "Her gün oyuna gir, sürpriz küre ödüllerini topla ve koleksiyonunu genişlet.",
      animationClass: "group-hover:animate-bounce"
    },
    {
      icon: RotateCcw,
      title: "Skor Sıfırlama",
      description: "İstediğin zaman skorunu sıfırla ve beyaz bir sayfa açarak yeniden başla.",
      animationClass: "group-hover:-rotate-180"
    },
    {
      icon: Languages,
      title: "Dil Seçenekleri",
      description: "Farklı dillerde kelime dağarcığını geliştir. Global oyuncularla tanış.",
      animationClass: "group-hover:scale-125 group-hover:rotate-12"
    },
    {
      icon: Layout,
      title: "Sade Arayüz",
      description: "Göz yormayan, modern ve kullanıcı dostu tasarım ile oyuna odaklan.",
      animationClass: "group-hover:skew-x-6 group-hover:scale-110"
    },
    {
      icon: Zap,
      title: "Akıcı Performans",
      description: "En eski cihazlarda bile takılmadan çalışan optimize edilmiş altyapı.",
      animationClass: "group-hover:text-yellow-400 group-hover:fill-current"
    },
    {
      icon: Sparkles,
      title: "Sürekli Güncel",
      description: "Düzenli olarak eklenen yeni emojiler ve oyun modları ile eğlence bitmez.",
      animationClass: "group-hover:animate-spin"
    }
  ];

  return (
    <div id="features" className="py-24 bg-gray-900/50 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
            Ekstra Özellikler
          </h2>
          <p className="text-gray-400">Oyun keyfini katlayan detaylar</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => (
            <FeatureItem key={idx} {...feature} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;