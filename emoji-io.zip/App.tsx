import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import InteractiveShowcase from './components/InteractiveShowcase';
import Modes from './components/Modes';
import Features from './components/Features';
import Pricing from './components/Pricing';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-brand-dark text-white font-sans selection:bg-brand-purple selection:text-white">
      <Navbar />
      
      <main>
        <Hero />
        <InteractiveShowcase />
        <Modes />
        <Features />
        <Pricing />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;